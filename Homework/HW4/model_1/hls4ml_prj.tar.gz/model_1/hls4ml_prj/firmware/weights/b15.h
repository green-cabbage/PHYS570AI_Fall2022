//Numpy array shape [1]
//Min 0.063959725201
//Max 0.063959725201
//Number of zeros 0

#ifndef B15_H_
#define B15_H_

#ifndef __SYNTHESIS__
model_default_t b15[1];
#else
model_default_t b15[1] = {0.063959725201};
#endif

#endif
